package selenium.base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import selenium.design.Browser;
import selenium.design.Element;
import utils.Reports;

public class SeleniumBase extends Reports implements Browser, Element{
	
	public static RemoteWebDriver driver;
	public static WebDriverWait wait;
	
	public void click(WebElement ele){	
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(ele));
			ele.click();
			testStepStatus("Pass", getElementText(ele)+" Clicked Successfully");
		} catch (NoSuchElementException e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		}
			
	}
	
	public int sizeOfWebElementList(List<WebElement> eles) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOfAllElements(eles));
			int size = eles.size();
			return size;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}
	
	public void verifyNoOfRecords(List<WebElement> eles) {
		if (sizeOfWebElementList(eles)==0){
			testStepStatus("Pass", "No records found");
		}else
			testStepStatus("Fail", sizeOfWebElementList(eles)+":Records found, not deleted successfully");		
	}
	
	public void selectDefaultResult(List<WebElement> eles, WebElement ele) {
			if (sizeOfWebElementList(eles)>1) {
				click(ele);
				testStepStatus("Pass", "First record Clicked Successfully");
			}else {
				testStepStatus("Fail", "No records available to select");
				throw new RuntimeException();
			}
	}

	public void clear(WebElement ele) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			ele.clear();
			testStepStatus("Pass", getElementText(ele)+" Element cleared Successfully");
		} catch (NoSuchElementException e) {
			testStepStatus("Fail", e.getMessage());
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
	}

	public void clearAndType(WebElement ele, String value) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			ele.clear();
			ele.sendKeys(value);
			testStepStatus("Pass", getElementText(ele)+" Entered Successfully");
		} catch (NoSuchElementException e) {
			testStepStatus("Fail", e.getMessage());
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
			}
	}

	public void appendText(WebElement ele, String value) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			ele.sendKeys(value);
			testStepStatus("Pass", value+"Appended to "+getElementText(ele)+" Successfully");
		} catch (NoSuchElementException e) {
			testStepStatus("Fail", e.getMessage());
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
	}

	public String getElementText(WebElement ele) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			String text = ele.getText();
			return text;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return null;
	}

	public String getAttributeValue(WebElement ele, String AttributeName) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			String attributeValue= ele.getAttribute(AttributeName);
			return attributeValue;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return null;
	}

	public String getTypedText(WebElement ele) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			String text = ele.getAttribute("value");
			return text;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return null;
	}

	public void selectDropdownUsingIndex(WebElement ele, int index) {
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeSelected(ele));
		Select select = new Select(ele);
		select.selectByIndex(index);
	}

	public void selectDropdownUsingText(WebElement ele, String text) {
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeSelected(ele));
		Select select = new Select(ele);
		select.selectByVisibleText(text);		
	}

	public void selectDropdownUsingValue(WebElement ele, String value) {
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeSelected(ele));
		Select select = new Select(ele);
		select.selectByValue(value);	
	}

	public boolean verifyExactText(WebElement ele, String text) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			if (ele.getText().equals(text)) {
				return true;
			}else
				return false;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return false;
	}

	public boolean verifyPartialText(WebElement ele, String text) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			if (ele.getText().contains(text)) {
				testStepStatus("Pass", getElementText(ele)+" Value verified Successfully");
				return true;
			}else
				return false;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return false;
	}

	public boolean verifyDisplayed(WebElement ele) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			if(ele.isDisplayed()) return true;
			else return false;
		} catch (NoSuchElementException e) {
			testStepStatus("Fail", e.getMessage());
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return false;
	}

	public boolean verifyEnabled(WebElement ele) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(ele));
			if(ele.isEnabled()) return true;
			else return false;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return false;
		
	}

	public boolean verifyDisabled(WebElement ele) {
		try {
			if(!ele.isEnabled()) return true;
			else return false;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return false;
	}

	public boolean verifySelected(WebElement ele) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeSelected(ele));
			if(ele.isSelected()) return true;
			else return false;
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
		return false;
	}

	public void startApp(String url) {
		 startApp("chrome", url);
	}

	public void startApp(String browser, String url) {
		try {
			if (browser.equalsIgnoreCase("chrome")) {
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
			}else if (browser.equalsIgnoreCase("firefox")) {
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
			}else if (browser.equalsIgnoreCase("ie")) {
				WebDriverManager.iedriver().setup();
				driver = new InternetExplorerDriver();
			}
			
			driver.get(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			testStepStatus("Pass", "Browser launced Successfully");
		} catch (Exception e) {
			testStepStatus("Fail", "Not Launched");
			throw new RuntimeException();
		}
	}

	public WebElement locateElement(String locator, String value) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			switch(locator.toLowerCase()){
			case "id": wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(value))); return driver.findElementById(value);
			case "name": wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(value))); return driver.findElementByName(value);
			case "class": wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(value))); return driver.findElementByClassName(value);
			case "xpath": wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(value))); return driver.findElementByXPath(value);
			case "link": wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(value))); return driver.findElementByLinkText(value);
			}
		} catch (NoSuchElementException e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		}
		return null;
	}

	public WebElement locateElement(String value) {
		WebElement ele = locateElement("id", value);
		return ele;
	}

	public List<WebElement> locateElements(String locator, String value) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			switch(locator.toLowerCase()){
			case "id": wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id(value))); return driver.findElementsById(value);
			case "name": wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.name(value))); return driver.findElementsByName(value);
			case "class": wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className(value))); return driver.findElementsByClassName(value);
			case "xpath": wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(value))); return driver.findElementsByXPath(value);
			case "link": wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText(value))); return driver.findElementsByLinkText(value);
			}
		} catch (NoSuchElementException e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		}
		return null;
	}

	public Alert switchAlert() {
		Alert alert = driver.switchTo().alert();
		return alert;
	}
	
	public void acceptAlert() {
		switchAlert().accept();
		testStepStatus("Pass", "Alert accepted Successfully");
	}

	public void dismissAlert() {
		switchAlert().dismiss();		
	}

	public String getAlertText() {
		String text = switchAlert().getText();
		return text;
	}

	public void typeAlertText(String value) {
		switchAlert().sendKeys(value);
		
	}

	public void switchToWindow(int index) {
		try {
			Set<String> windowHandles = driver.getWindowHandles();
			List<String> list = new ArrayList<String>(windowHandles);
			String selectedWindow = list.get(index);
			driver.switchTo().window(selectedWindow);
			testStepStatus("Pass", "Window switched Successfully");
		} catch (NoSuchWindowException e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
	}

	public void switchToFrame(int index) {
		try {
			driver.switchTo().frame(index);
		} catch (NoSuchFrameException e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
	}

	public void switchToFrame(String idOrName) {
		try {
			driver.switchTo().frame(idOrName);
		} catch (NoSuchFrameException e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
	}

	public void switchToFrame(WebElement ele) {
		try {
			driver.switchTo().frame(ele);
		} catch (NoSuchFrameException e) {
			testStepStatus("Fail", e.getMessage());
			throw new RuntimeException();
		} catch (Exception e) {
			testStepStatus("Fail", e.getMessage());
		}
	}

	public void defaultContent() {
		driver.switchTo().defaultContent();
	}

	public void parentFrame() {
		driver.switchTo().parentFrame();
	}

	public boolean verifyUrl(String url) {
		if (driver.getCurrentUrl().equals(url)) {
			return true;
		}else return false;
		
	}

	public boolean verifyTitle(String title) {
		if(driver.getTitle().equalsIgnoreCase(title)){
			return true;
		}else return false;
	}

	public void closeApp() {
		driver.close();
	}

	public void closeAllBrowser() {
		driver.quit();
	}
	
	public long takeScreenshot() throws IOException {
		try {
			long random = (long) ((Math.random())*99999999L);
			File src = driver.getScreenshotAs(OutputType.FILE);
			File trg = new File("./snaps/img"+random+".png");
			FileUtils.copyFile(src, trg);
			return random;
		} catch (WebDriverException e) {
			
		}
		return 0;
	}

}
