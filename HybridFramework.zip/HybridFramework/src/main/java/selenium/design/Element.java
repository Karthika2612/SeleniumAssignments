package selenium.design;

import java.util.List;

import org.openqa.selenium.WebElement;

public interface Element {
	
	public void click(WebElement ele);
	public void clear(WebElement ele);
	public int sizeOfWebElementList(List<WebElement> eles);
	public void verifyNoOfRecords(List<WebElement> eles);
	public void clearAndType(WebElement ele, String value);
	public void appendText(WebElement ele, String value);
	public String getElementText(WebElement ele);
	public String getAttributeValue(WebElement ele, String AttributeName);
	public String getTypedText(WebElement ele);
	public void selectDropdownUsingIndex(WebElement ele, int index);
	public void selectDropdownUsingText(WebElement ele, String text);
	public void selectDropdownUsingValue(WebElement ele, String value);
	public boolean verifyExactText(WebElement ele, String text);
	public boolean verifyPartialText(WebElement ele, String text);
	public boolean verifyDisplayed(WebElement ele);
	public boolean verifyEnabled(WebElement ele);
	public boolean verifyDisabled(WebElement ele);
	public boolean verifySelected(WebElement ele);
	
}
