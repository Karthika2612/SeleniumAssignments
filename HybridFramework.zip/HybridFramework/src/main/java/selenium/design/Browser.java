package selenium.design;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;


public interface Browser {
	
	public void startApp(String url);
	public void startApp(String browser, String url);
	public WebElement locateElement(String locator, String value);
	public WebElement locateElement(String value);
	public List<WebElement> locateElements(String locator, String value);
	public Alert switchAlert();
	public void acceptAlert();
	public void dismissAlert();
	public String getAlertText();
	public void typeAlertText(String value);
	public void switchToWindow(int index);
	public void switchToFrame(int index);
	public void switchToFrame(String idOrName);
	public void switchToFrame(WebElement ele);
	public void defaultContent();
	public void parentFrame();
	public boolean verifyUrl(String url);
	public boolean verifyTitle(String title);
	public void closeApp();
	public void closeAllBrowser();

}
