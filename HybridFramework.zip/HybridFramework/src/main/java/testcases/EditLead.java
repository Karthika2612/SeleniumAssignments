package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import testng.base.ProjectSpecificMethods;

public class EditLead extends ProjectSpecificMethods{

	@BeforeTest
	public void provideDetails() {

		sheetName = "EditLead";
		testName="EditLead";
		testDesc="To edit lead";
		testAuthor="Karthika";
		testCategory="Smoke";
	}
	
	@Test(dataProvider="dataFromExcel")
	public void editLead(String uName, String pWord, String fName, String cName) throws InterruptedException {

		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLeads()
		.enterFirstName(fName)
		.clickFindLeadsButton()
		.clickFirstResult()
		.clickEditButton()
		.updateCompanyName(cName)
		.clickUpdateButton()
		.verifyCompanyName(cName);
		
	}

}
