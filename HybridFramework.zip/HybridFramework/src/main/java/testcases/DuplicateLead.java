package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import testng.base.ProjectSpecificMethods;

public class DuplicateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void provideDetails() {
		
		sheetName = "DuplicateLead";
		testName="DuplicateLead";
		testDesc="To duplicate lead";
		testAuthor="Karthika";
		testCategory="Smoke";
	}
	
	@Test(dataProvider="dataFromExcel")
	public void duplicateLead(String uName, String pWord, String email) throws InterruptedException {
		
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLeads()
		.clickEmailTab()
		.enterEmailAddress(email)
		.clickFindLeadsButton()
		.clickFirstResult()
		.getFirstName()
		.clickDuplicateButton()
		.clickCreateLeadButton()
		.verifyDuplicateLeadName();
		
	}

}
