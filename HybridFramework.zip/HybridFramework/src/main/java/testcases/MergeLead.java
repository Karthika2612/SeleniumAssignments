package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import testng.base.ProjectSpecificMethods;

public class MergeLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void provideDetails() {
		
		sheetName = "MergeLead";
		testName="MergeLead";
		testDesc="To merge lead";
		testAuthor="Karthika";
		testCategory="Smoke";
	}

	@Test(dataProvider="dataFromExcel")
	public void mergeLead(String uName, String pWord, String fLeadId, String sLeadId) throws InterruptedException {

		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeads()
		.ClickMergeLeads()
		.clickFromLead()
		.switchWindow()
		.enterLeadId(fLeadId)
		.clickFindLeads()
		.getFirstLeadId()
		.selectFirstRecord()
		.switchBackToWindow()
		.clickToLead()
		.switchWindow()
		.enterLeadId(sLeadId)
		.clickFindLeads()
		.selectFirstRecord()
		.switchBackToWindow()
		.clickMergeButton()
		.clickAcceptAlert()
		.clickFindLeads()
		.enterLeadId()
		.clickFindLeadsButton()
		.verifyDisplayedRecords();
	}
}
