package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import testng.base.ProjectSpecificMethods;

public class LoginLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void provideDetails() {
		sheetName="Login";
		testName="LoginLogout";
		testDesc="To check login";
		testAuthor="Karthika";
		testCategory="Smoke";
	}
	
	@Test(dataProvider="dataFromExcel")
	public void loginLogout(String uName, String pWord) {
		
		  new LoginPage() 
		  .enterUserName(uName) 
		  .enterPassword(pWord)
		  .clickLoginButton() 
		  .clickLogoutButton();
		 
		
	}
	
}
