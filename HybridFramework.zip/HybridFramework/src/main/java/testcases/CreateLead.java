package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import testng.base.ProjectSpecificMethods;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void provideDetails() {
		
		sheetName = "CreateLead";
		testName="CreateLead";
		testDesc="To create lead";
		testAuthor="Karthika";
		testCategory="Smoke";
	}
	
	@Test(dataProvider="dataFromExcel")
	public void createLead(String uName, String pWord, String fName, String lName, String cName) throws InterruptedException {
		
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickSubmitButton()
		.verifyFirstName(fName);
	}
}
