package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods{

	public CreateLeadPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.ID, using="createLeadForm_companyName") WebElement edtCompanyName;
	@FindBy(how=How.ID, using="createLeadForm_firstName") WebElement edtFirstName;
	@FindBy(how=How.ID, using="createLeadForm_lastName") WebElement edtLastName;
	@FindBy(how=How.NAME, using="submitButton") WebElement btnCreateLead;
	
	
	public CreateLeadPage enterCompanyName(String cName) {
		clearAndType(edtCompanyName, cName);
		return this;
	}
	
	public CreateLeadPage enterFirstName(String fName) {
		clearAndType(edtFirstName, fName);
		return this;
	}

	public CreateLeadPage enterLastName(String lName) {
		clearAndType(edtLastName, lName);
		return this;
	}
	
	public ViewLeadPage clickSubmitButton() {
		click(btnCreateLead);
		return new ViewLeadPage();
	}
}
