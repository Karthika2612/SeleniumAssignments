package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods{
	
	public MyLeadsPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.LINK_TEXT, using="Create Lead") WebElement lnkCreateLead;
	@FindBy(how=How.XPATH, using="//a[text()='Find Leads']") WebElement lnkFindLead;
	@FindBy(how=How.XPATH, using="//a[text()='Merge Leads']") WebElement lnkMergeLead;
	
	public CreateLeadPage clickCreateLead() {
		click(lnkCreateLead);
		return new CreateLeadPage();
	}

	public FindLeadsPage clickFindLeads() throws InterruptedException {
		click(lnkFindLead);
		Thread.sleep(2000);
		return new FindLeadsPage();
	}
	
	public MergeLeadPage ClickMergeLeads() {
		click(lnkMergeLead);
		return new MergeLeadPage();
	}

}
