package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class FindLeadsPage extends ProjectSpecificMethods{
	public FindLeadsPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="(//input[@name='firstName'])[3]") WebElement edtFirstName;
	@FindBy(how=How.XPATH, using="//button[text()='Find Leads']") WebElement btnFindLeads;
	@FindBy(how=How.XPATH, using="//tr/td/div/a[@class='linktext']") WebElement rcdFirstResult;
	@FindBy(how=How.XPATH, using="//span[text()='Email']") WebElement tabEmail;
	@FindBy(how=How.XPATH, using="//input[@name='emailAddress']") WebElement edtEmail;
	@FindBy(how=How.XPATH, using="//span[text()='Phone']") WebElement tabPhone;
	@FindBy(how=How.XPATH, using="//input[@name='phoneNumber']") WebElement edtPhoneNumber;
	@FindBy(how=How.XPATH, using="//input[@name='id']") WebElement edtLeadId;
	@FindBy(how=How.XPATH, using="//tr/td/div/a[@class='linktext']/../../..") List<WebElement> resultRecords;
	
	
	public FindLeadsPage enterFirstName(String name) {
		clearAndType(edtFirstName, name);
		return this;
	}

	public FindLeadsPage clickFindLeadsButton() throws InterruptedException {
		click(btnFindLeads);
		Thread.sleep(2000);
		return this;
	}
	
	public ViewLeadPage clickFirstResult() throws InterruptedException {
		/*
		 * try { click(rcdFirstResult); } catch (Exception e) {
		 * System.out.println("No Records found"); throw new RuntimeException(); }
		 */
		  selectDefaultResult(resultRecords, rcdFirstResult);
		  return new ViewLeadPage();
	}
	
	public FindLeadsPage clickEmailTab() {
		click(tabEmail);
		return this;
	}
	
	public FindLeadsPage enterEmailAddress(String email) {
		clearAndType(edtEmail, email);
		return this;
	}
	
	public FindLeadsPage clickPhoneNumberTab() {
		click(tabPhone);
		return this;
	}
	
	public FindLeadsPage enterPhoneNumber(String phoneNumber) {
		clearAndType(edtPhoneNumber,phoneNumber);
		return this;
	}
	
	public FindLeadsPage enterLeadId() {
		clearAndType(edtLeadId, lbeLeadID);
		return this;
	}
	
	public FindLeadsPage verifyDisplayedRecords() {
		verifyNoOfRecords(resultRecords);
		return this;
	}

}
