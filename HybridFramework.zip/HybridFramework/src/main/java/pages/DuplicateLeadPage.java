package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class DuplicateLeadPage extends ProjectSpecificMethods{
	public DuplicateLeadPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//input[@value='Create Lead']") WebElement btnCreateLead;
	
	public ViewLeadPage clickCreateLeadButton() throws InterruptedException {
		click(btnCreateLead);
		return new ViewLeadPage();
	}

}
