package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//input[@id='username']") WebElement edtUsername;
	@FindBy(how=How.XPATH, using="//input[@id='password']") WebElement edtPassword;
	@FindBy(how=How.XPATH, using="//input[@type='submit']") WebElement btnLogin;
	
	public LoginPage enterUserName(String username) {
		clearAndType(edtUsername, username);
		return this;
	}
	
	public LoginPage enterPassword(String password) {
		clearAndType(edtPassword, password);
		return this;
	}
	
	public WelcomePage clickLoginButton() {
		click(btnLogin);
		return new WelcomePage();
	}
	
}
