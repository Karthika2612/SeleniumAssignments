package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{
	
	public ViewLeadPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//a[text()='Edit']") WebElement btnEdit;
	@FindBy(how=How.XPATH, using="//span[@id='viewLead_companyName_sp']") WebElement lblCompanyName;
	@FindBy(how=How.XPATH, using="//span[@id='viewLead_firstName_sp']") WebElement lblFirstName;
	@FindBy(how=How.XPATH, using="//a[text()='Duplicate Lead']") WebElement btnDuplicateLead;
	@FindBy(how=How.XPATH, using="//a[text()='Delete']") WebElement btnDelete;
	
	
	public EditLeadPage clickEditButton() {
		click(btnEdit);
		return new EditLeadPage();
	}

	public ViewLeadPage verifyCompanyName(String cName) {
		verifyPartialText(lblCompanyName, cName);
		return this;
	}

	public ViewLeadPage verifyFirstName(String fName) {
		verifyPartialText(lblFirstName, fName);
		return this;
	}
	
	public DuplicateLeadPage clickDuplicateButton() {
		click(btnDuplicateLead);
		return new DuplicateLeadPage();
	}
	
	public ViewLeadPage verifyDuplicateLeadName() {
		verifyPartialText(lblFirstName, lbeFirstName);
		return this;
	}
	
	public ViewLeadPage getFirstName() {
		lbeFirstName = getElementText(lblFirstName);
		return this;
	}
	
	public ViewLeadPage getLeadId() {
		lbeLeadID = getElementText(lblCompanyName).replaceAll("[^0-9]", "");
		return this;
	}
	
	public MyLeadsPage clickDeleteButton() {
		click(btnDelete);
		return new MyLeadsPage();
	}
}
