package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class EditLeadPage extends ProjectSpecificMethods {
	public EditLeadPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//input[@id='updateLeadForm_companyName']") WebElement edtCompanyName;
	@FindBy(how=How.XPATH, using="//input[@value='Update']") WebElement btnUpdate;
	
	public EditLeadPage updateCompanyName(String cName) {
		clearAndType(edtCompanyName, cName);
		return this;
	}

	public ViewLeadPage clickUpdateButton() {
		click(btnUpdate);
		return new ViewLeadPage();
	}
}
