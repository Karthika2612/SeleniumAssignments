package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods{
	
	public WelcomePage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//input[@class='decorativeSubmit']") WebElement btnLogout;
	@FindBy(how=How.XPATH, using="//a[contains(text(),'CRM')]") WebElement lnkCrmSfa;
	
	public LoginPage clickLogoutButton() {
		click(btnLogout);
		return new LoginPage();
	}
	
	public MyHomePage clickCRMSFA() {
		click(lnkCrmSfa);
		return new MyHomePage();

	}
}
