package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import testng.base.ProjectSpecificMethods;

public class MergeLeadPage extends ProjectSpecificMethods{

	MergeLeadPage(){
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//img[@src='/images/fieldlookup.gif']") WebElement iconFromLead;
	@FindBy(how=How.XPATH, using="//input[@name='id']") WebElement edtLeadId;
	@FindBy(how=How.XPATH, using="//button[text()='Find Leads']") WebElement btnFindLeads;
	@FindBy(how=How.XPATH, using="//a[@class='linktext']") WebElement rcdFirstElement;
	@FindBy(how=How.XPATH, using="(//img[@src='/images/fieldlookup.gif'])[2]") WebElement iconToLead;
	@FindBy(how=How.XPATH, using="//a[text()='Merge']") WebElement btnMerge;
	
	public MergeLeadPage clickFromLead() {
		click(iconFromLead);
		return this;
	}
	
	public MergeLeadPage switchWindow() throws InterruptedException{
		switchToWindow(1);
		return this;
	}
	
	public MergeLeadPage enterLeadId(String LeadId) {
		clearAndType(edtLeadId, LeadId);
		return this;
	}
	
	public MergeLeadPage clickFindLeads() throws InterruptedException {
		click(btnFindLeads);
		Thread.sleep(2000);
		return this;
	}
	
	public MergeLeadPage getFirstLeadId() {
		lbeLeadID = getElementText(rcdFirstElement);
		return this;
	}
	
	public MergeLeadPage selectFirstRecord() {
		click(rcdFirstElement);
		return this;
	}
		
	public MergeLeadPage switchBackToWindow() {
		switchToWindow(0);
		return this;
	}
	
	public MergeLeadPage clickToLead() {
		click(iconToLead);
		return this;
	}
	
	public MergeLeadPage clickMergeButton(){
		click(btnMerge);
		return this;
	}

	public MyLeadsPage clickAcceptAlert() throws InterruptedException {
		acceptAlert();
		Thread.sleep(3000);
		return new MyLeadsPage();
	}
}
