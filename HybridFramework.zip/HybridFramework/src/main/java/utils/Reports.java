package utils;

import java.io.IOException;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public abstract class Reports {
	
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public static ExtentTest test, node;
	public String testName, testDesc, testAuthor, testCategory;
	
	@BeforeSuite
	public void startReport(){
		reporter = new ExtentHtmlReporter("./ExtentReports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	
	public abstract long takeScreenshot() throws IOException;
	public void testStepStatus(String status, String msg) {
		try {
			if (status.equalsIgnoreCase("pass")) {
				node.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeScreenshot()+".png").build());
			}else if (status.equalsIgnoreCase("fail"))
				node.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeScreenshot()+".png").build());
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
}
